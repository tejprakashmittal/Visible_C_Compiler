/**
 * 
 */
/**
 * @author tez
 *
 */
module compiler_front_end {
	requires java.datatransfer;
	requires java.desktop;
}